var searchData=
[
  ['nsidata_0',['NSIData',['../classrepository_1_1model_1_1_n_s_i_data.html',1,'repository::model']]]
];
