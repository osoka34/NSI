var searchData=
[
  ['config_0',['Config',['../classconfig_1_1settings_1_1_settings_1_1_config.html',1,'config::settings::Settings']]]
];
