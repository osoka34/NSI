var searchData=
[
  ['settings_0',['Settings',['../classconfig_1_1settings_1_1_settings.html',1,'config::settings']]]
];
