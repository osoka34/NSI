var searchData=
[
  ['close_0',['close',['../classrepository_1_1repository_1_1_repository.html#a67cac12d27307ff690dc4c07ea729c6f',1,'repository::repository::Repository']]],
  ['config_1',['Config',['../classconfig_1_1settings_1_1_settings_1_1_config.html',1,'config::settings::Settings']]]
];
