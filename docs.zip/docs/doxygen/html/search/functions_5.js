var searchData=
[
  ['load_5fnsi_5fdata_0',['load_nsi_data',['../classservice_1_1application__nsi_1_1_application_n_s_i_service.html#ab79650361e1a0dd22bb1c582037abbe8',1,'service::application_nsi::ApplicationNSIService']]]
];
