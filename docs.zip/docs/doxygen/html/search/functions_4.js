var searchData=
[
  ['get_5fnsi_5fdata_0',['get_nsi_data',['../classrepository_1_1repository_1_1_repository.html#a8c72352ed01d0c35fe950f4e3be69443',1,'repository.repository.Repository.get_nsi_data()'],['../classservice_1_1application__nsi_1_1_application_n_s_i_service.html#ae893a922046acc237ffabd406d41af17',1,'service.application_nsi.ApplicationNSIService.get_nsi_data()']]],
  ['get_5fnsi_5fdata_5fview_1',['get_nsi_data_view',['../classrepository_1_1repository_1_1_repository.html#ac7378b677df27291cf11e3d36e670d0b',1,'repository::repository::Repository']]]
];
